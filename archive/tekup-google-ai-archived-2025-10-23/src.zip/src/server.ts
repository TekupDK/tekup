import express from "express";
import type { Express } from "express";
import { chatRouter } from "./routes/chat";
import { healthRouter } from "./routes/health";
import dashboardRouter from "./api/dashboardRoutes";
import { expressErrorHandler } from "./middleware/errorHandler";
import { enrichContextMiddleware } from "./middleware/contextEnrichment";
import { apiLimiter, chatLimiter, dashboardLimiter } from "./middleware/rateLimiter";
import { sanitizeInput, validateInputLength } from "./middleware/sanitizer";
import { requireAuth } from "./middleware/authMiddleware";

export function createServer(): Express {
    const app = express();
    app.use(express.json({ limit: "1mb" }));
    app.use(express.urlencoded({ extended: false }));

    // Security Headers Middleware (based on penetration test recommendations)
    app.use((req, res, next) => {
        // Content Security Policy - prevent XSS and data injection attacks
        res.setHeader(
            "Content-Security-Policy",
            "default-src 'self'; " +
            "script-src 'self' 'unsafe-inline' 'unsafe-eval' https://challenges.cloudflare.com https://accounts.google.com https://*.clerk.accounts.dev https://*.clerk.com; " +
            "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; " +
            "font-src 'self' https://fonts.gstatic.com data:; " +
            "img-src 'self' data: https: blob:; " +
            "connect-src 'self' https://tekup-renos.onrender.com https://*.clerk.accounts.dev https://*.clerk.com https://accounts.google.com; " +
            "frame-src 'self' https://challenges.cloudflare.com https://accounts.google.com https://*.clerk.accounts.dev; " +
            "frame-ancestors 'self';"
        );

        // X-Frame-Options - prevent clickjacking attacks
        res.setHeader("X-Frame-Options", "SAMEORIGIN");

        // X-XSS-Protection - enable XSS filter in older browsers
        res.setHeader("X-XSS-Protection", "1; mode=block");

        // X-Content-Type-Options - prevent MIME type sniffing (already exists, keeping it)
        res.setHeader("X-Content-Type-Options", "nosniff");

        // Referrer-Policy - control referrer information
        res.setHeader("Referrer-Policy", "strict-origin-when-cross-origin");

        // Permissions-Policy - disable unnecessary browser features
        res.setHeader("Permissions-Policy", "geolocation=(), microphone=(), camera=()");

        // Strict-Transport-Security (HSTS) - enforce HTTPS
        if (process.env.NODE_ENV === "production") {
            res.setHeader("Strict-Transport-Security", "max-age=31536000; includeSubDomains");
        }

        // X-Permitted-Cross-Domain-Policies - prevent Flash/PDF cross-domain issues
        res.setHeader("X-Permitted-Cross-Domain-Policies", "none");

        // Cross-Origin-Embedder-Policy - Spectre attack protection
        res.setHeader("Cross-Origin-Embedder-Policy", "require-corp");

        next();
    });

    // Environment-based CORS configuration
    const frontendUrl = process.env.FRONTEND_URL || "http://localhost:5173";
    const corsOrigin = process.env.CORS_ORIGIN;

    // Build allowed origins list - REMOVED WILDCARD for security
    const allowedOrigins = process.env.NODE_ENV === "production"
        ? [
            frontendUrl,
            corsOrigin,
            "https://tekup-renos-1.onrender.com"
        ].filter(Boolean) // Remove undefined values
        : [
            "http://localhost:5173",
            "http://localhost:3000",
            frontendUrl,
            corsOrigin
        ].filter(Boolean); // Remove undefined values, NO WILDCARD

    console.log("CORS Configuration:", {
        frontendUrl,
        corsOrigin,
        allowedOrigins,
        nodeEnv: process.env.NODE_ENV,
        isProduction: process.env.NODE_ENV === "production"
    });

    app.use((req, res, next) => {
        const origin = req.headers.origin;
        console.log("CORS Request:", { origin, method: req.method, url: req.url });

        // Always set CORS headers in production for allowed origins
        if (process.env.NODE_ENV !== "production") {
            // Development: Allow all
            res.header("Access-Control-Allow-Origin", origin || "*");
            console.log("CORS Allowed (dev mode):", origin);
        } else if (origin && allowedOrigins.includes(origin)) {
            // Production: Only allow whitelisted origins
            res.header("Access-Control-Allow-Origin", origin);
            console.log("CORS Allowed (prod mode):", origin);
        } else {
            console.log("CORS Blocked:", origin, "Allowed origins:", allowedOrigins);
        }

        res.header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
        res.header("Access-Control-Allow-Headers", "Content-Type, Authorization");
        res.header("Access-Control-Allow-Credentials", "true");

        // Handle preflight requests
        if (req.method === "OPTIONS") {
            return res.sendStatus(200);
        }
        next();
    });

    // Health endpoint (no rate limiting for monitoring)
    app.use("/health", healthRouter);

    // Rate Limiting - Protect against DoS attacks
    app.use("/api/", apiLimiter); // General API protection

    // Dashboard API routes (with authentication, rate limiting)
    // NOTE: Auth currently disabled (set ENABLE_AUTH=true in production)
    app.use("/api/dashboard", requireAuth, dashboardLimiter, dashboardRouter);

    // Chat endpoint (with authentication, strict rate limiting, sanitization, and validation)
    // NOTE: Auth currently disabled (set ENABLE_AUTH=true in production)
    app.use("/api/chat", requireAuth, chatLimiter, validateInputLength(5000), sanitizeInput, enrichContextMiddleware);
    app.use("/api/chat", chatRouter);

    // Error handling middleware (skal være sidst)
    app.use(expressErrorHandler);

    return app;
}
