import type { ParsedLead } from "./leadParser";
import {
    EmailResponseGenerator,
    type GeneratedEmailResponse,
} from "./emailResponseGenerator";
import { sendGenericEmail } from "./gmailService";
import { logger } from "../logger";

/**
 * Auto-response configuration
 */
export interface AutoResponseConfig {
    enabled: boolean;
    requireApproval: boolean;
    responseDelay: number; // seconds to wait before responding
    maxResponsesPerDay: number;
}

/**
 * Response status tracking
 */
export interface ResponseStatus {
    leadId: string;
    leadName: string;
    status: "pending" | "sent" | "approved" | "rejected" | "failed";
    generatedAt: Date;
    sentAt?: Date;
    error?: string;
}

/**
 * Email auto-response service
 */
export class EmailAutoResponseService {
    private generator: EmailResponseGenerator;
    private config: AutoResponseConfig;
    private responsesSentToday: number = 0;
    private lastResetDate: Date = new Date();
    private pendingResponses: Map<string, GeneratedEmailResponse> = new Map();
    private responseStatuses: Map<string, ResponseStatus> = new Map();

    constructor(config?: Partial<AutoResponseConfig>) {
        this.generator = new EmailResponseGenerator();
        this.config = {
            enabled: config?.enabled ?? true,
            requireApproval: config?.requireApproval ?? false,
            responseDelay: config?.responseDelay ?? 30, // 30 seconds default
            maxResponsesPerDay: config?.maxResponsesPerDay ?? 50,
        };
    }

    /**
     * Process a new lead and generate/send auto-response
     */
    async processLead(lead: ParsedLead): Promise<ResponseStatus> {
        logger.info(
            {
                leadId: lead.emailId,
                name: lead.name,
                source: lead.source,
            },
            "Processing lead for auto-response"
        );

        // Check if service is enabled
        if (!this.config.enabled) {
            logger.info("Auto-response is disabled");
            return this.createStatus(lead, "rejected", "Auto-response disabled");
        }

        // Check if lead has email
        if (!lead.email) {
            logger.warn({ leadId: lead.emailId }, "Lead has no email address");
            return this.createStatus(lead, "failed", "No email address");
        }

        // Check daily limit
        this.resetDailyCountIfNeeded();
        if (this.responsesSentToday >= this.config.maxResponsesPerDay) {
            logger.warn(
                { limit: this.config.maxResponsesPerDay },
                "Daily response limit reached"
            );
            return this.createStatus(lead, "rejected", "Daily limit reached");
        }

        try {
            // Generate response
            const response = await this.generateResponseForLead(lead);

            // Store status
            const status = this.createStatus(lead, "pending");
            this.responseStatuses.set(lead.emailId, status);

            if (this.config.requireApproval) {
                // Store for manual approval
                this.pendingResponses.set(lead.emailId, response);
                logger.info(
                    { leadId: lead.emailId },
                    "Response generated, awaiting approval"
                );
                status.status = "approved"; // Will be changed to "approved" or "rejected"
                return status;
            } else {
                // Send automatically after delay
                if (this.config.responseDelay > 0) {
                    logger.info(
                        { delay: this.config.responseDelay },
                        "Delaying response"
                    );
                    await this.delay(this.config.responseDelay * 1000);
                }

                await this.sendResponse(lead.emailId, response);
                status.status = "sent";
                status.sentAt = new Date();
                this.responsesSentToday++;

                logger.info(
                    { leadId: lead.emailId, to: response.to },
                    "Auto-response sent successfully"
                );

                return status;
            }
        } catch (err) {
            logger.error(
                { err, leadId: lead.emailId },
                "Failed to process lead for auto-response"
            );
            return this.createStatus(lead, "failed", (err as Error).message);
        }
    }

    /**
     * Generate email response for a lead
     */
    private async generateResponseForLead(
        lead: ParsedLead
    ): Promise<GeneratedEmailResponse> {
        // Determine response type based on task type
        let template: "moving" | "regular" | "quote-request" = "quote-request";

        if (
            lead.taskType?.toLowerCase().includes("flytte") ||
            lead.taskType?.toLowerCase().includes("flytterengøring")
        ) {
            template = "moving";
        } else if (
            lead.taskType?.toLowerCase().includes("fast") ||
            lead.taskType?.toLowerCase().includes("ugentlig")
        ) {
            template = "regular";
        }

        return this.generator.generateQuickResponse(lead, template);
    }

    /**
     * Send an email response
     */
    private async sendResponse(
        leadId: string,
        response: GeneratedEmailResponse
    ): Promise<void> {
        await sendGenericEmail({
            to: response.to,
            subject: response.subject,
            body: response.body,
            threadId: response.replyToThreadId,
        });
    }

    /**
     * Approve a pending response and send it
     */
    async approvePendingResponse(leadId: string): Promise<boolean> {
        const response = this.pendingResponses.get(leadId);
        const status = this.responseStatuses.get(leadId);

        if (!response || !status) {
            logger.warn({ leadId }, "No pending response found");
            return false;
        }

        try {
            await this.sendResponse(leadId, response);
            status.status = "sent";
            status.sentAt = new Date();
            this.responsesSentToday++;
            this.pendingResponses.delete(leadId);

            logger.info({ leadId }, "Pending response approved and sent");
            return true;
        } catch (err) {
            logger.error({ err, leadId }, "Failed to send approved response");
            status.status = "failed";
            status.error = (err as Error).message;
            return false;
        }
    }

    /**
     * Reject a pending response
     */
    async rejectPendingResponse(leadId: string): Promise<boolean> {
        const status = this.responseStatuses.get(leadId);

        if (!status) {
            logger.warn({ leadId }, "No pending response found");
            return false;
        }

        status.status = "rejected";
        this.pendingResponses.delete(leadId);

        logger.info({ leadId }, "Pending response rejected");
        return true;
    }

    /**
     * Get all pending responses
     */
    getPendingResponses(): Array<{
        leadId: string;
        response: GeneratedEmailResponse;
        status: ResponseStatus;
    }> {
        const pending: Array<{
            leadId: string;
            response: GeneratedEmailResponse;
            status: ResponseStatus;
        }> = [];

        for (const [leadId, response] of this.pendingResponses.entries()) {
            const status = this.responseStatuses.get(leadId);
            if (status) {
                pending.push({ leadId, response, status });
            }
        }

        return pending;
    }

    /**
     * Get response status for a lead
     */
    getResponseStatus(leadId: string): ResponseStatus | undefined {
        return this.responseStatuses.get(leadId);
    }

    /**
     * Get all response statuses
     */
    getAllResponseStatuses(): ResponseStatus[] {
        return Array.from(this.responseStatuses.values());
    }

    /**
     * Get service statistics
     */
    getStatistics() {
        const statuses = Array.from(this.responseStatuses.values());
        return {
            totalResponses: statuses.length,
            sent: statuses.filter((s) => s.status === "sent").length,
            pending: statuses.filter((s) => s.status === "pending").length,
            failed: statuses.filter((s) => s.status === "failed").length,
            approved: statuses.filter((s) => s.status === "approved").length,
            rejected: statuses.filter((s) => s.status === "rejected").length,
            todayCount: this.responsesSentToday,
            dailyLimit: this.config.maxResponsesPerDay,
            enabled: this.config.enabled,
            requireApproval: this.config.requireApproval,
        };
    }

    /**
     * Update configuration
     */
    updateConfig(config: Partial<AutoResponseConfig>): void {
        this.config = { ...this.config, ...config };
        logger.info({ config: this.config }, "Auto-response config updated");
    }

    /**
     * Create a response status object
     */
    private createStatus(
        lead: ParsedLead,
        status: ResponseStatus["status"],
        error?: string
    ): ResponseStatus {
        return {
            leadId: lead.emailId,
            leadName: lead.name || "Unknown",
            status,
            generatedAt: new Date(),
            error,
        };
    }

    /**
     * Reset daily counter if it's a new day
     */
    private resetDailyCountIfNeeded(): void {
        const now = new Date();
        if (now.getDate() !== this.lastResetDate.getDate()) {
            this.responsesSentToday = 0;
            this.lastResetDate = now;
            logger.info("Daily response counter reset");
        }
    }

    /**
     * Delay helper
     */
    private delay(ms: number): Promise<void> {
        return new Promise((resolve) => setTimeout(resolve, ms));
    }
}

// Singleton instance
let autoResponseService: EmailAutoResponseService | null = null;

/**
 * Get the auto-response service instance
 */
export function getAutoResponseService(
    config?: Partial<AutoResponseConfig>
): EmailAutoResponseService {
    if (!autoResponseService) {
        autoResponseService = new EmailAutoResponseService(config);
    }
    return autoResponseService;
}
