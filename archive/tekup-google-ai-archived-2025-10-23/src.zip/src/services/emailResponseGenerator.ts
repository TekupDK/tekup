import type { ParsedLead } from "./leadParser";
import { GeminiProvider } from "../llm/geminiProvider";
import { appConfig } from "../config";
import { logger } from "../logger";
import { findNextAvailableSlot } from "./calendarService";

/**
 * Email response template context
 */
export interface EmailResponseContext {
    lead: ParsedLead;
    responseType: "tilbud" | "bekræftelse" | "follow-up" | "info";
    additionalContext?: string;
    includeBookingSlots?: boolean; // New: Include available booking times in email
    bookingDuration?: number; // Duration in minutes for suggested booking slots
}

/**
 * Generated email response
 */
export interface GeneratedEmailResponse {
    subject: string;
    body: string;
    to: string;
    cc?: string[];
    replyToThreadId?: string;
}

/**
 * Email response generator using Gemini AI
 */
export class EmailResponseGenerator {
    private llm: GeminiProvider;

    constructor() {
        const apiKey = appConfig.llm.GEMINI_KEY;
        if (!apiKey) {
            throw new Error("GEMINI_KEY is required for email response generation");
        }
        this.llm = new GeminiProvider(apiKey);
    }

    /**
     * Generate an email response for a lead
     */
    async generateResponse(
        context: EmailResponseContext
    ): Promise<GeneratedEmailResponse> {
        const { lead, responseType, additionalContext, includeBookingSlots, bookingDuration } = context;

        logger.info(
            {
                leadId: lead.emailId,
                name: lead.name,
                responseType,
                includeBookingSlots,
            },
            "Generating email response"
        );

        // Fetch available booking slots if requested
        let bookingSlotsContext = "";
        if (includeBookingSlots) {
            bookingSlotsContext = await this.getBookingSlotsContext(
                bookingDuration || 120, // Default 2 hours
                3 // Number of slots to suggest
            );
        }

        const prompt = this.buildPrompt(
            lead,
            responseType,
            additionalContext,
            bookingSlotsContext
        );

        try {
            const content = await this.llm.completeChat(
                [
                    {
                        role: "system",
                        content: this.getSystemPrompt(),
                    },
                    {
                        role: "user",
                        content: prompt,
                    },
                ],
                {
                    model: "gemini-2.0-flash-exp",
                    temperature: 0.7,
                    maxTokens: 800,
                }
            );

            const parsed = this.parseEmailResponse(content);

            const result: GeneratedEmailResponse = {
                subject: parsed.subject || this.generateDefaultSubject(lead, responseType),
                body: parsed.body || content,
                to: lead.email || "",
                replyToThreadId: lead.threadId,
            };

            logger.info(
                {
                    leadId: lead.emailId,
                    subject: result.subject,
                    hasBookingSlots: includeBookingSlots,
                },
                "Email response generated successfully"
            );

            return result;
        } catch (err) {
            logger.error(
                { err, leadId: lead.emailId },
                "Failed to generate email response"
            );
            throw err;
        }
    }

    /**
     * Generate a quick response for common scenarios
     */
    async generateQuickResponse(
        lead: ParsedLead,
        template: "moving" | "regular" | "quote-request",
        includeBookingSlots: boolean = true
    ): Promise<GeneratedEmailResponse> {
        const responseType = this.getResponseTypeFromTemplate(template);
        const additionalContext = this.getTemplateContext(template, lead);

        // Determine booking duration based on template
        let bookingDuration = 120; // Default 2 hours
        if (template === "moving") {
            bookingDuration = 240; // 4 hours for moving
        } else if (template === "regular") {
            bookingDuration = 150; // 2.5 hours for regular cleaning
        }

        return this.generateResponse({
            lead,
            responseType,
            additionalContext,
            includeBookingSlots,
            bookingDuration,
        });
    }

    /**
     * Build the prompt for the LLM
     */
    private buildPrompt(
        lead: ParsedLead,
        responseType: string,
        additionalContext?: string,
        bookingSlotsContext?: string
    ): string {
        const parts: string[] = [];

        parts.push("**LEAD INFORMATION:**");
        parts.push(`- Navn: ${lead.name || "Ikke oplyst"}`);
        parts.push(`- Email: ${lead.email || "Ikke oplyst"}`);
        parts.push(`- Telefon: ${lead.phone || "Ikke oplyst"}`);
        parts.push(`- Adresse: ${lead.address || "Ikke oplyst"}`);
        parts.push(`- Boligtype: ${lead.propertyType || "Ikke oplyst"}`);
        if (lead.squareMeters) {
            parts.push(`- Størrelse: ${lead.squareMeters} m²`);
        }
        if (lead.rooms) {
            parts.push(`- Værelser: ${lead.rooms}`);
        }
        parts.push(`- Behov: ${lead.taskType || "Ikke oplyst"}`);
        parts.push(`- Kilde: ${lead.source}`);
        parts.push("");

        parts.push("**OPGAVE:**");
        parts.push(`Generer en ${responseType} email til ${lead.name || "kunden"}.`);
        parts.push("");

        if (additionalContext) {
            parts.push("**EKSTRA KONTEKST:**");
            parts.push(additionalContext);
            parts.push("");
        }

        if (bookingSlotsContext) {
            parts.push("**LEDIGE TIDSPUNKTER:**");
            parts.push(bookingSlotsContext);
            parts.push("Inkluder disse ledige tidspunkter i emailen på en naturlig måde.");
            parts.push("Inviter kunden til at vælge et tidspunkt eller foreslå et alternativ.");
            parts.push("");
        }

        parts.push("**FORMAT:**");
        parts.push("SUBJECT: [Skriv emnet her]");
        parts.push("");
        parts.push("BODY:");
        parts.push("[Skriv email-indholdet her]");
        parts.push("");
        parts.push("**VIGTIGE RETNINGSLINJER:**");
        parts.push("- Brug dansk sprog");
        parts.push("- Vær professionel men venlig");
        parts.push("- Inkluder relevante detaljer fra lead-informationen");
        parts.push("- Afslut med kontaktoplysninger: +45 22 65 02 26, info@rendetalje.dk");
        parts.push("- Brug Rendetalje.dk som virksomhedsnavn");
        parts.push("- Hvis du giver tilbud, vær specifik om pris og tidsestimat");

        return parts.join("\n");
    }

    /**
     * Get system prompt for email generation
     */
    private getSystemPrompt(): string {
        return `Du er en professionel kundeservicemedarbejder hos Rendetalje.dk, 
et rengøringsfirma i Aarhus-området. Din opgave er at generere venlige, 
professionelle og hjælpsomme email-svar til kunder og leads.

Rendetalje.dk tilbyder:
- Fast rengøring (ugentlig/14-dages interval)
- Flytterengøring
- Erhvervsrengøring
- Vinduespudsning

Standard priser:
- Fast rengøring: 250-300 kr/time (typisk 2-3 timer)
- Flytterengøring: 300 kr/time (typisk 4-6 timer for villa)
- Minimum booking: 2 timer

Kontaktinfo:
- Telefon: +45 22 65 02 26
- Email: info@rendetalje.dk
- Hjemmeside: www.rendetalje.dk

Vigtige punkter:
- Vær præcis med priser og tidsestimater
- Tilbyd konkrete tidspunkter hvis muligt
- Spørg om yderligere detaljer hvis nødvendigt
- Vær imødekommende og professionel
- Brug emoji sparsomt (maks 2-3 per email)`;
    }

    /**
     * Parse the LLM response into subject and body
     */
    private parseEmailResponse(content: string): {
        subject: string | null;
        body: string | null;
    } {
        const subjectMatch = content.match(/SUBJECT:\s*(.+?)(?:\n|$)/i);
        const bodyMatch = content.match(/BODY:\s*(.+)/is);

        let subject = subjectMatch ? subjectMatch[1].trim() : null;
        let body = bodyMatch ? bodyMatch[1].trim() : null;

        // Clean up subject - remove quotes if present
        if (subject) {
            subject = subject.replace(/^["']|["']$/g, "");
        }

        return { subject, body };
    }

    /**
     * Generate a default subject line
     */
    private generateDefaultSubject(lead: ParsedLead, responseType: string): string {
        const name = lead.name || "kunde";

        switch (responseType) {
            case "tilbud":
                return `Tilbud på ${lead.taskType || "rengøring"} - ${name}`;
            case "bekræftelse":
                return `Bekræftelse af din henvendelse - ${name}`;
            case "follow-up":
                return `Opfølgning på din henvendelse om rengøring`;
            case "info":
                return `Yderligere information om vores rengøringsydelser`;
            default:
                return `Din henvendelse til Rendetalje.dk`;
        }
    }

    /**
     * Get response type from template name
     */
    private getResponseTypeFromTemplate(
        template: "moving" | "regular" | "quote-request"
    ): "tilbud" | "bekræftelse" | "follow-up" | "info" {
        switch (template) {
            case "moving":
                return "tilbud";
            case "regular":
                return "tilbud";
            case "quote-request":
                return "tilbud";
            default:
                return "info";
        }
    }

    /**
     * Get available booking slots context for email
     * @param durationMinutes - Duration of booking in minutes
     * @param numberOfSlots - Number of alternative slots to find (default 3)
     * @returns Formatted string with available booking times in Danish
     */
    private async getBookingSlotsContext(
        durationMinutes: number,
        numberOfSlots: number = 3
    ): Promise<string> {
        try {
            const slots: Array<{ start: string; end: string }> = [];
            let searchStart = new Date();

            // Find multiple available slots
            for (let i = 0; i < numberOfSlots; i++) {
                const slot = await findNextAvailableSlot(
                    "primary",
                    durationMinutes,
                    searchStart,
                    14 // Search within 14 days
                );

                if (!slot) {
                    logger.warn(
                        { slotsFound: slots.length, requested: numberOfSlots },
                        "Could not find all requested booking slots"
                    );
                    break;
                }

                slots.push(slot);

                // Move search start to after this slot to find next available time
                searchStart = new Date(slot.end);
                searchStart.setMinutes(searchStart.getMinutes() + 60); // Add 1 hour buffer
            }

            if (slots.length === 0) {
                logger.warn("No available booking slots found");
                return "Ingen ledige tidspunkter tilgængelige i øjeblikket. Vi kontakter dig for at finde en passende tid.";
            }

            // Format slots in Danish
            const formatter = new Intl.DateTimeFormat("da-DK", {
                weekday: "long",
                day: "numeric",
                month: "long",
                hour: "2-digit",
                minute: "2-digit",
                timeZone: "Europe/Copenhagen",
            });

            const formattedSlots = slots.map((slot, index) => {
                const startDate = new Date(slot.start);
                const formattedDate = formatter.format(startDate);
                // Capitalize first letter
                return `${index + 1}. ${formattedDate.charAt(0).toUpperCase()}${formattedDate.slice(1)}`;
            });

            logger.info(
                { slotsFound: slots.length, durationMinutes },
                "Found available booking slots"
            );

            return `Vi har ledige tidspunkter:\n${formattedSlots.join("\n")}`;
        } catch (err) {
            logger.error({ err }, "Failed to fetch booking slots");
            return ""; // Return empty string on error - email can still be generated without slots
        }
    }

    /**
     * Get template-specific context
     */
    private getTemplateContext(
        template: "moving" | "regular" | "quote-request",
        lead: ParsedLead
    ): string {
        switch (template) {
            case "moving":
                return `Dette er en flytterengøring. 
Giv et konkret tilbud baseret på boligens størrelse (${lead.squareMeters || "150"} m²).
Typisk pris: 300 kr/time, estimeret 4-6 timer for en villa.
Inkluder information om hvad der er inkluderet i flytterengøringen.`;

            case "regular":
                return `Dette er en henvendelse om fast rengøring.
Giv et tilbud på ugentlig eller 14-dages rengøring.
Typisk pris: 250-300 kr/time, 2-3 timer per besøg.
Spørg om ønsket frekvens og hvilke områder der skal rengøres.`;

            case "quote-request":
                return `Kunden ønsker et uforpligtende tilbud.
Giv en prisindikation baseret på de oplyste detaljer.
Inviter til en gratis besigtigelse hvis nødvendigt.`;

            default:
                return "";
        }
    }
}
