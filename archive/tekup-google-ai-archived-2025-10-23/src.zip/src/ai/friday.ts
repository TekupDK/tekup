/**
 * 🤖 Friday AI - RenOS Intelligent Assistant
 * 
 * Friday er en professionel dansk rengøringsassistent der hjælper med:
 * - Lead håndtering og opfølgning
 * - Booking og kalender styring
 * - Kunde information og historik
 * - Tilbud og prisberegning
 * - Generel hjælp og vejledning
 * 
 * Personlighed: Venlig, professionel, kompetent, dansk
 */

import type { ChatMessage } from "../types";
import { getRecentLeads } from "../services/leadMonitor";
import { getAutoResponseService } from "../services/emailAutoResponseService";
import {
    findNextAvailableSlot,
    listUpcomingEvents,
    isTimeSlotAvailable,
    type CalendarEventSummary
} from "../services/calendarService";
import { logger } from "../logger";

export interface FridayContext {
    intent?: string;
    confidence?: number;
    userMessage: string;
    history: ChatMessage[];
}

export interface FridayResponse {
    message: string;
    suggestions?: string[];
    data?: unknown;
}

/**
 * Friday AI System Prompt - Definerer personlighed og adfærd
 * Used for future LLM integration
 */
export const FRIDAY_SYSTEM_PROMPT = `Du er Friday, en professionel dansk AI-assistent for Rendetalje - en rengøringsfirma.

🎯 DIN ROLLE:
- Hjælpe med leads, bookinger, kunder og tilbud
- Besvare spørgsmål om RenOS systemet
- Guide brugeren til de rigtige funktioner
- Være venlig, professionel og hjælpsom

💬 DIN KOMMUNIKATIONSSTIL:
- Brug dansk sprog naturligt og korrekt
- Vær kortfattet og præcis (max 3-4 linjer for simple svar)
- Brug emojis sparsomt og professionelt (📧 📅 👤 💰 ✅)
- Vær positiv og løsningsorienteret
- Undgå robotagtig eller for formel tone

📊 HVAD DU KAN HJÆLPE MED:
1. **Leads** - Vis seneste leads, søg i leads, lead statistik
2. **Email Auto-Response** - Se ventende emails, godkend/afvis, send automatiske svar
3. **Kalender & Booking** - Find ledige tider, book møder, tjek tilgængelighed, flyt aftaler
4. **Kunder** - Søg kunder, vis kunde historik, kunde information
5. **Tilbud** - Lav tilbud, send tilbud, tilbuds historik
6. **Statistik** - Dashboard, omsætning, performance metrics
7. **Generel hjælp** - Vejledning, tips, forklaring af funktioner

❌ HVAD DU IKKE KAN:
- Ændre priser eller kontraktvilkår
- Få adgang til andre firmers data
- Lave betalinger eller transaktioner
- Slette kunde data uden godkendelse

🎨 FORMATERING:
- Brug **fed** til vigtige nøgleord
- Brug lister med • for flere punkter
- Brug numre (1. 2. 3.) for trin-for-trin guides
- Brug line breaks for læsbarhed

VIGTIG: Hvis brugeren spørger om noget du ikke kan hjælpe med, vær ærlig og suggest hvad du KAN hjælpe med i stedet.`;

/**
 * Friday AI - Håndterer naturlige samtaler og returnerer intelligente svar
 */
export class FridayAI {
    /**
     * Proces bruger besked og generer intelligent svar
     */
    async respond(context: FridayContext): Promise<FridayResponse> {
        const { intent, userMessage, history } = context;

        logger.debug({ intent, message: userMessage }, "Friday AI processing message");

        // Håndter forskellige intent typer
        switch (intent) {
            case "analytics.overview":
                return this.handleAnalyticsQuery(userMessage);

            case "email.lead":
                return this.handleLeadQuery(userMessage);

            case "email.response":
                return this.handleEmailResponse(userMessage);

            case "calendar.booking":
                return this.handleBookingQuery(userMessage);

            case "calendar.availability":
                return await this.handleAvailabilityQuery(userMessage);

            case "calendar.reschedule":
                return this.handleRescheduleQuery(userMessage);

            case "greeting":
                return this.handleGreeting(userMessage);

            case "help":
                return this.handleHelpRequest(userMessage);

            default:
                return this.handleUnknownIntent(userMessage, history);
        }
    }

    /**
     * Håndter analytics og lead forespørgsler
     */
    private handleAnalyticsQuery(message: string): FridayResponse {
        const lowerMessage = message.toLowerCase();

        // Check if asking about leads specifically
        if (
            lowerMessage.includes("lead") ||
            lowerMessage.includes("seneste") ||
            lowerMessage.includes("nye") ||
            lowerMessage.includes("vis")
        ) {
            return this.getLeadsResponse();
        }

        // General analytics
        return {
            message: `📊 **Statistik & Analytics**\n\nGå til Dashboard-fanen for at se:\n• Kundestatistik og omsætning\n• Seneste leads og bookinger\n• Email response statistik\n• Cache performance\n• Samtale oversigt\n\nHvad vil du vide mere om?`,
            suggestions: ["Vis seneste leads", "Email statistik", "Kalender overblik", "Vis kunder"],
        };
    }

    /**
     * Hent og formater leads data
     */
    private getLeadsResponse(): FridayResponse {
        const leads = getRecentLeads(5);

        if (leads.length === 0) {
            return {
                message: `📭 **Ingen leads endnu**\n\nDer er ingen leads i systemet lige nu.\n\nLeads bliver automatisk hentet fra:\n• Rengøring.nu\n• Leadmail.no\n• Din Gmail inbox\n\nDe opdateres hvert 20. minut.`,
                suggestions: ["Email hjælp", "Kalender hjælp", "Vis dashboard"],
            };
        }

        let response = `📧 **Seneste ${leads.length} Leads**\n\n`;

        leads.forEach((lead, index) => {
            const date = new Date(lead.receivedAt);
            const formattedDate = date.toLocaleDateString("da-DK", {
                day: "2-digit",
                month: "short",
            });
            const formattedTime = date.toLocaleTimeString("da-DK", {
                hour: "2-digit",
                minute: "2-digit",
            });

            response += `**${index + 1}. ${lead.name || "Ikke angivet"}**\n`;

            if (lead.email || lead.phone) {
                const contact = [lead.email, lead.phone].filter(Boolean).join(" • ");
                response += `   ${contact}\n`;
            }

            if (lead.taskType) {
                response += `   🧹 ${lead.taskType}\n`;
            }

            if (lead.address) {
                response += `   📍 ${lead.address}\n`;
            }

            response += `   🕐 ${formattedDate} kl. ${formattedTime} (${lead.source})\n\n`;
        });

        return {
            message: response.trim(),
            suggestions: ["Email til lead", "Book møde", "Vis dashboard"],
            data: leads,
        };
    }

    /**
     * Håndter lead-relaterede forespørgsler
     */
    private handleLeadQuery(_message: string): FridayResponse {
        return this.getLeadsResponse();
    }

    /**
     * Håndter email response forespørgsler
     */
    private handleEmailResponse(message: string): FridayResponse {
        const lowerMessage = message.toLowerCase();

        // Check for pending responses
        const autoResponseService = getAutoResponseService();
        const pendingResponses = autoResponseService.getPendingResponses();
        const stats = autoResponseService.getStatistics();

        if (lowerMessage.includes("pending") || lowerMessage.includes("godkend")) {
            if (pendingResponses.length === 0) {
                return {
                    message: `📧 **Ingen ventende emails**\n\nDer er ingen emails der venter på godkendelse lige nu.\n\nAutomatisk email service status:\n• Sendt i dag: ${stats.sent}\n• Ventende: ${stats.pending}\n• Total: ${stats.totalResponses}`,
                    suggestions: ["Send email til lead", "Kalender hjælp", "Hjælp"],
                };
            }

            let response = `📧 **Ventende Email Responses (${pendingResponses.length})**\n\n`;
            pendingResponses.slice(0, 3).forEach((pending, index) => {
                const lead = pending.status;
                response += `**${index + 1}. ${lead.leadName}**\n`;
                response += `   Status: ${lead.status}\n`;
                response += `   Oprettet: ${new Date(lead.generatedAt).toLocaleDateString("da-DK")}\n\n`;
            });

            return {
                message: response.trim(),
                suggestions: ["Godkend alle", "Send email til lead", "Vis statistik"],
            };
        }

        // General email response help
        return {
            message: `📧 **Email Auto-Response**\n\nJeg kan hjælpe med:\n• Se ventende emails til godkendelse\n• Send automatiske svar til leads\n• Tjek email statistikker\n• Godkend/afvis ventende responses\n\nHvad vil du gerne gøre?`,
            suggestions: ["Vis ventende emails", "Send email til lead", "Email statistik"],
        };
    }

    /**
     * Håndter booking forespørgsler
     */
    private handleBookingQuery(_message: string): FridayResponse {
        return {
            message: `📅 **Booking & Kalender**\n\nJeg kan hjælpe med at:\n• Finde ledige tider\n• Se kommende bookinger\n• Booke nye møder\n• Reservere tidsslots\n\nHvad vil du gerne?`,
            suggestions: ["Find ledig tid i morgen", "Vis kommende bookinger", "Book møde"],
        };
    }

    /**
     * Håndter availability forespørgsler
     */
    private async handleAvailabilityQuery(message: string): Promise<FridayResponse> {
        const lowerMessage = message.toLowerCase();

        // Check for specific time requests
        if (lowerMessage.includes("morgen") || lowerMessage.includes("i morgen")) {
            return await this.findTomorrowAvailability();
        }

        if (lowerMessage.includes("eftermiddag") || lowerMessage.includes("aften")) {
            return await this.findAfternoonAvailability();
        }

        // General availability check
        return {
            message: `📅 **Tjek Tilgængelighed**\n\nJeg kan finde ledige tider for:\n• **I morgen** - Hurtigt overblik\n• **Specifikke dage** - Vælg dato og tid\n• **Næste uge** - Langtidsplanlægning\n• **Fleksible tider** - Bedste tilgængelige slots\n\nHvad vil du gerne tjekke?`,
            suggestions: ["Ledig tid i morgen", "Find næste uge", "Tjek specifik dag"],
        };
    }

    /**
     * Håndter reschedule forespørgsler
     */
    private handleRescheduleQuery(message: string): FridayResponse {
        return {
            message: `🔄 **Flyt Aftaler**\n\nJeg kan hjælpe med at:\n• Flytte eksisterende bookinger\n• Finde nye tidspunkter\n• Sende opdateringer til kunder\n• Koordinere med Google Calendar\n\nHvilken booking vil du flytte?`,
            suggestions: ["Vis kommende bookinger", "Find alternativ tid", "Kontakt kunde"],
        };
    }

    /**
     * Håndter hilsner
     */
    private handleGreeting(_message: string): FridayResponse {
        const greetings = [
            "Hej! 👋 Jeg er Friday, din RenOS assistent. Hvordan kan jeg hjælpe dig i dag?",
            "Hej! 😊 Velkommen til RenOS. Hvad kan jeg gøre for dig?",
            "Hej der! 🌟 Jeg er klar til at hjælpe. Hvad skal vi kigge på?",
        ];

        const randomGreeting = greetings[Math.floor(Math.random() * greetings.length)];

        return {
            message: randomGreeting,
            suggestions: ["Vis seneste leads", "Email hjælp", "Kalender hjælp", "Vis dashboard"],
        };
    }

    /**
     * Håndter hjælp forespørgsler
     */
    private handleHelpRequest(_message: string): FridayResponse {
        return {
            message: `💡 **Hvad jeg kan hjælpe med**\n\n📧 **Leads** - "Vis seneste leads" eller "Søg i leads"\n📨 **Email** - "Vis ventende emails" eller "Send auto-svar"\n📅 **Kalender** - "Find ledig tid i morgen" eller "Book møde"\n👤 **Kunder** - "Vis kunder" eller "Søg efter kunde"\n💰 **Tilbud** - "Lav tilbud" eller "Send tilbud"\n📊 **Statistik** - "Vis dashboard" eller "Omsætning"\n\nHvad vil du prøve?`,
            suggestions: ["Vis seneste leads", "Email hjælp", "Kalender hjælp", "Vis dashboard"],
        };
    }

    /**
     * Find availability for tomorrow
     */
    private async findTomorrowAvailability(): Promise<FridayResponse> {
        try {
            // Find next available 2-hour slot starting tomorrow morning
            const tomorrow = new Date();
            tomorrow.setDate(tomorrow.getDate() + 1);
            tomorrow.setHours(9, 0, 0, 0); // 9 AM tomorrow

            const slot = await findNextAvailableSlot("primary", 120, tomorrow, 7); // 2 hours, next 7 days

            if (!slot) {
                return {
                    message: `📅 **Ingen ledige tider fundet**\n\nJeg kunne ikke finde nogen 2-timers slots ledige i morgen eller de næste 7 dage.\n\nPrøv:\n• En anden dag\n• Kortere varighed\n• Tidligere på dagen`,
                    suggestions: ["Tjek eftermiddag", "Find 1-times slot", "Vis alle bookinger"],
                };
            }

            const startDate = new Date(slot.start);
            const endDate = new Date(slot.end);

            return {
                message: `📅 **Ledig tid fundet!**\n\n**${startDate.toLocaleDateString("da-DK", {
                    weekday: "long",
                    day: "numeric",
                    month: "long"
                })}**\n⏰ ${startDate.toLocaleTimeString("da-DK", {
                    hour: "2-digit",
                    minute: "2-digit"
                })} - ${endDate.toLocaleTimeString("da-DK", {
                    hour: "2-digit",
                    minute: "2-digit"
                })}\n\nVil du booke denne tid?`,
                suggestions: ["Ja, book denne tid", "Find andre tider", "Vis alle bookinger"],
                data: slot,
            };
        } catch (error) {
            logger.error({ error }, "Failed to find tomorrow availability");
            return {
                message: `❌ **Fejl ved tjek af tilgængelighed**\n\nDer opstod en fejl ved søgning efter ledige tider i morgen.\n\nPrøv igen senere eller kontakt support.`,
                suggestions: ["Prøv igen", "Tjek manuel kalender", "Hjælp"],
            };
        }
    }

    /**
     * Find afternoon availability
     */
    private async findAfternoonAvailability(): Promise<FridayResponse> {
        try {
            const today = new Date();
            const afternoon = new Date(today);
            afternoon.setHours(13, 0, 0, 0); // 1 PM today

            if (afternoon.getTime() < today.getTime()) {
                // If it's already past 1 PM, check tomorrow afternoon
                afternoon.setDate(afternoon.getDate() + 1);
            }

            const slot = await findNextAvailableSlot("primary", 90, afternoon, 3); // 1.5 hours, next 3 days

            if (!slot) {
                return {
                    message: `📅 **Ingen eftermiddagstider fundet**\n\nJeg kunne ikke finde nogen 1,5-times eftermiddags slots.\n\nPrøv:\n• Morgen tider i stedet\n• En anden dag\n• Kortere varighed`,
                    suggestions: ["Tjek morgen", "Find i morgen", "Vis alle tider"],
                };
            }

            const startDate = new Date(slot.start);
            const endDate = new Date(slot.end);

            return {
                message: `🌅 **Eftermiddagstid fundet!**\n\n**${startDate.toLocaleDateString("da-DK", {
                    weekday: "long",
                    day: "numeric",
                    month: "short"
                })}**\n⏰ ${startDate.toLocaleTimeString("da-DK", {
                    hour: "2-digit",
                    minute: "2-digit"
                })} - ${endDate.toLocaleTimeString("da-DK", {
                    hour: "2-digit",
                    minute: "2-digit"
                })}\n\nPerfekt til eftermiddagsmøder!`,
                suggestions: ["Book denne tid", "Find andre eftermiddage", "Se alle bookinger"],
                data: slot,
            };
        } catch (error) {
            logger.error({ error }, "Failed to find afternoon availability");
            return {
                message: `❌ **Fejl ved eftermiddags søgning**\n\nKunne ikke søge efter eftermiddags tider.\n\nPrøv igen eller kontakt support.`,
                suggestions: ["Prøv morgen", "Manuel søgning", "Hjælp"],
            };
        }
    }

    /**
     * Check conversation context for better responses
     */
    private getConversationContext(history: ChatMessage[]): string {
        if (history.length === 0) return "";

        // Look for recent topics in conversation
        const recentMessages = history.slice(-3); // Last 3 messages
        let context = "";

        for (const msg of recentMessages) {
            const lowerContent = msg.content.toLowerCase();

            if (lowerContent.includes("email") || lowerContent.includes("besked")) {
                context += "Email samtale • ";
            }
            if (lowerContent.includes("kalender") || lowerContent.includes("tid") || lowerContent.includes("møde")) {
                context += "Kalender samtale • ";
            }
            if (lowerContent.includes("lead") || lowerContent.includes("kunde")) {
                context += "Lead samtale • ";
            }
        }

        return context.trim();
    }

    /**
     * Håndter ukendte intents - giv hjælpsomme forslag
     */
    private handleUnknownIntent(message: string, history: ChatMessage[]): FridayResponse {
        // Check for common patterns in the message
        const lowerMessage = message.toLowerCase();

        // Simple keyword matching for better UX
        if (lowerMessage.includes("hjælp") || lowerMessage.includes("help")) {
            return this.handleHelpRequest(message);
        }

        if (
            lowerMessage.includes("hej") ||
            lowerMessage.includes("hallo") ||
            lowerMessage.includes("goddag")
        ) {
            return this.handleGreeting(message);
        }

        // Check for email/calendar patterns
        if (
            lowerMessage.includes("email") ||
            lowerMessage.includes("besked") ||
            lowerMessage.includes("send")
        ) {
            return this.handleEmailResponse(message);
        }

        if (
            lowerMessage.includes("tid") ||
            lowerMessage.includes("møde") ||
            lowerMessage.includes("aftale") ||
            lowerMessage.includes("kalender")
        ) {
            return this.handleBookingQuery(message);
        }

        // Get conversation context for better response
        const conversationContext = this.getConversationContext(history);

        // Generic helpful response with context awareness
        let contextMessage = "";
        if (conversationContext) {
            contextMessage = `\n\nJeg kan se vi har talt om: ${conversationContext}\n\n`;
        }

        return {
            message: `Hmm, jeg er ikke helt sikker på hvad du mener. 🤔${contextMessage}Kan du prøve at omformulere, eller skal jeg hjælpe med noget andet?\n\nJeg er bedst til:\n• Leads og kunde information\n• Email auto-response\n• Booking og kalender\n• Statistik og overblik`,
            suggestions: ["Vis seneste leads", "Email hjælp", "Kalender hjælp", "Hjælp"],
        };
    }
}

/**
 * Export singleton instance
 */
export const fridayAI = new FridayAI();
