import { GoogleGenerativeAI } from "@google/generative-ai";
import type { ChatCompletionMessageParam } from "openai/resources/chat/completions";
import type { LLMCompletionOptions, LLMProvider } from "./llmProvider";

/**
 * Gemini AI provider implementation
 */
export class GeminiProvider implements LLMProvider {
    private readonly client: GoogleGenerativeAI;
    private readonly defaultModel: string = "gemini-2.0-flash-exp";

    constructor(apiKey: string) {
        if (!apiKey) {
            throw new Error("GEMINI_KEY is required to use the Gemini provider");
        }

        this.client = new GoogleGenerativeAI(apiKey);
    }

    async completeChat(
        messages: ChatCompletionMessageParam[],
        options?: LLMCompletionOptions
    ): Promise<string> {
        const model = this.client.getGenerativeModel({
            model: options?.model ?? this.defaultModel,
        });

        // Convert OpenAI message format to Gemini format
        const geminiMessages = this.convertMessages(messages);

        // Gemini uses a different API structure
        const chat = model.startChat({
            history: geminiMessages.history,
            generationConfig: {
                temperature: options?.temperature ?? 0.7,
                maxOutputTokens: options?.maxTokens ?? 800,
            },
        });

        const result = await chat.sendMessage(geminiMessages.lastMessage);
        const response = result.response;
        const completion = response.text();

        if (!completion) {
            throw new Error("Gemini response did not include any content");
        }

        return completion;
    }

    /**
     * Convert OpenAI message format to Gemini format
     */
    private convertMessages(messages: ChatCompletionMessageParam[]): {
        history: Array<{ role: string; parts: Array<{ text: string }> }>;
        lastMessage: string;
    } {
        const history: Array<{ role: string; parts: Array<{ text: string }> }> = [];
        let systemPrompt = "";
        let lastUserMessage = "";

        for (const msg of messages) {
            if (msg.role === "system") {
                // Gemini doesn't have a system role, prepend to first user message
                systemPrompt = msg.content as string;
            } else if (msg.role === "user") {
                lastUserMessage = msg.content as string;
            } else if (msg.role === "assistant") {
                history.push({
                    role: "model", // Gemini uses "model" instead of "assistant"
                    parts: [{ text: msg.content as string }],
                });
            }
        }

        // If we have a system prompt, prepend it to the last user message
        if (systemPrompt && lastUserMessage) {
            lastUserMessage = `${systemPrompt}\n\n${lastUserMessage}`;
        }

        return {
            history,
            lastMessage: lastUserMessage,
        };
    }
}
