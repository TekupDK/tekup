import type { ChatCompletionMessageParam } from "openai/resources/chat/completions";

export interface LLMCompletionOptions {
    model?: string;
    temperature?: number;
    maxTokens?: number;
}

export interface LLMProvider {
    completeChat(
        messages: ChatCompletionMessageParam[],
        options?: LLMCompletionOptions
    ): Promise<string>;
}
