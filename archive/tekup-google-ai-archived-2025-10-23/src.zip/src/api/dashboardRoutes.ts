import express, { Request, Response } from "express";
import { queryCustomers, getCustomerConversations } from "../services/customerService";
import { cache } from "../services/cacheService";
import { prisma } from "../services/databaseService";
import { logger } from "../logger";

const router = express.Router();

/**
 * Dashboard API Routes
 * 
 * Provides data endpoints for the monitoring dashboard
 */

// Health check
router.get("/health", (_req: Request, res: Response) => {
    res.json({
        status: "ok",
        timestamp: new Date().toISOString(),
    });
});

// Dashboard overview stats
router.get("/stats/overview", async (_req: Request, res: Response) => {
    try {
        const [
            totalCustomers,
            totalLeads,
            totalBookings,
            totalQuotes,
            activeConversations,
        ] = await Promise.all([
            prisma.customer.count({ where: { status: "active" } }),
            prisma.lead.count(),
            prisma.booking.count(),
            prisma.quote.count(),
            prisma.conversation.count({ where: { status: "active" } }),
        ]);

        // Calculate total revenue from accepted quotes
        const acceptedQuotes = await prisma.quote.findMany({
            where: { status: "accepted" },
            select: { total: true },
        });
        const totalRevenue = acceptedQuotes.reduce(
            (sum, quote) => sum + quote.total,
            0
        );

        res.json({
            customers: totalCustomers,
            leads: totalLeads,
            bookings: totalBookings,
            quotes: totalQuotes,
            conversations: activeConversations,
            revenue: totalRevenue,
        });
    } catch (error) {
        logger.error({ error }, "Failed to fetch overview stats");
        res.status(500).json({ error: "Failed to fetch stats" });
    }
});

// Recent leads
router.get("/leads/recent", async (req: Request, res: Response) => {
    try {
        const limit = parseInt(req.query.limit as string) || 10;

        const leads = await prisma.lead.findMany({
            take: limit,
            orderBy: { createdAt: "desc" },
            include: {
                customer: {
                    select: {
                        name: true,
                        email: true,
                    },
                },
                quotes: {
                    select: {
                        status: true,
                        total: true,
                    },
                },
                bookings: {
                    select: {
                        status: true,
                        startTime: true,
                    },
                },
            },
        });

        res.json(leads);
    } catch (error) {
        logger.error({ error }, "Failed to fetch recent leads");
        res.status(500).json({ error: "Failed to fetch leads" });
    }
});

// Lead pipeline stats (by status)
router.get("/leads/pipeline", async (_req: Request, res: Response) => {
    try {
        const pipeline = await prisma.lead.groupBy({
            by: ["status"],
            _count: true,
        });

        const formatted = pipeline.map((item) => ({
            status: item.status,
            count: item._count,
        }));

        res.json(formatted);
    } catch (error) {
        logger.error({ error }, "Failed to fetch lead pipeline");
        res.status(500).json({ error: "Failed to fetch pipeline" });
    }
});

// Recent bookings
router.get("/bookings/recent", async (req: Request, res: Response) => {
    try {
        const limit = parseInt(req.query.limit as string) || 10;

        const bookings = await prisma.booking.findMany({
            take: limit,
            orderBy: { createdAt: "desc" },
            include: {
                lead: {
                    select: {
                        name: true,
                        email: true,
                        taskType: true,
                    },
                },
            },
        });

        res.json(bookings);
    } catch (error) {
        logger.error({ error }, "Failed to fetch recent bookings");
        res.status(500).json({ error: "Failed to fetch bookings" });
    }
});

// Upcoming bookings
router.get("/bookings/upcoming", async (_req: Request, res: Response) => {
    try {
        const now = new Date();

        const bookings = await prisma.booking.findMany({
            where: {
                startTime: { gte: now },
                status: { in: ["scheduled", "confirmed"] },
            },
            orderBy: { startTime: "asc" },
            take: 20,
            include: {
                lead: {
                    select: {
                        name: true,
                        email: true,
                        phone: true,
                        taskType: true,
                        address: true,
                    },
                },
            },
        });

        res.json(bookings);
    } catch (error) {
        logger.error({ error }, "Failed to fetch upcoming bookings");
        res.status(500).json({ error: "Failed to fetch bookings" });
    }
});

// Email activity stats
router.get("/emails/activity", async (req: Request, res: Response) => {
    try {
        const days = parseInt(req.query.days as string) || 7;
        const startDate = new Date();
        startDate.setDate(startDate.getDate() - days);

        const messages = await prisma.emailMessage.findMany({
            where: {
                sentAt: { gte: startDate },
            },
            select: {
                direction: true,
                isAiGenerated: true,
                aiModel: true,
                sentAt: true,
            },
        });

        // Group by day and direction
        const activity = messages.reduce((acc, msg) => {
            const day = msg.sentAt.toISOString().split("T")[0];
            if (!acc[day]) {
                acc[day] = { inbound: 0, outbound: 0, aiGenerated: 0 };
            }
            if (msg.direction === "inbound") {
                acc[day].inbound++;
            } else {
                acc[day].outbound++;
                if (msg.isAiGenerated) {
                    acc[day].aiGenerated++;
                }
            }
            return acc;
        }, {} as Record<string, { inbound: number; outbound: number; aiGenerated: number }>);

        res.json(activity);
    } catch (error) {
        logger.error({ error }, "Failed to fetch email activity");
        res.status(500).json({ error: "Failed to fetch email activity" });
    }
});

// AI performance metrics
router.get("/ai/metrics", async (_req: Request, res: Response) => {
    try {
        const totalMessages = await prisma.emailMessage.count({
            where: { isAiGenerated: true },
        });

        const byModel = await prisma.emailMessage.groupBy({
            by: ["aiModel"],
            where: { isAiGenerated: true },
            _count: true,
        });

        const modelStats = byModel.map((item) => ({
            model: item.aiModel || "unknown",
            count: item._count,
        }));

        res.json({
            total: totalMessages,
            byModel: modelStats,
        });
    } catch (error) {
        logger.error({ error }, "Failed to fetch AI metrics");
        res.status(500).json({ error: "Failed to fetch AI metrics" });
    }
});

// Cache statistics
router.get("/cache/stats", (_req: Request, res: Response) => {
    try {
        const stats = cache.getStats();
        const hitRate = cache.getHitRate();

        res.json({
            hits: stats.hits,
            misses: stats.misses,
            size: stats.size,
            hitRate: (hitRate * 100).toFixed(2) + "%",
        });
    } catch (error) {
        logger.error({ error }, "Failed to fetch cache stats");
        res.status(500).json({ error: "Failed to fetch cache stats" });
    }
});

// Top customers by revenue
router.get("/customers/top", async (req: Request, res: Response) => {
    try {
        const limit = parseInt(req.query.limit as string) || 10;

        const customers = await prisma.customer.findMany({
            where: { status: "active" },
            orderBy: { totalRevenue: "desc" },
            take: limit,
            select: {
                id: true,
                name: true,
                email: true,
                totalLeads: true,
                totalBookings: true,
                totalRevenue: true,
                lastContactAt: true,
            },
        });

        res.json(customers);
    } catch (error) {
        logger.error({ error }, "Failed to fetch top customers");
        res.status(500).json({ error: "Failed to fetch customers" });
    }
});

// Revenue over time
router.get("/revenue/timeline", async (req: Request, res: Response) => {
    try {
        const days = parseInt(req.query.days as string) || 30;
        const startDate = new Date();
        startDate.setDate(startDate.getDate() - days);

        const quotes = await prisma.quote.findMany({
            where: {
                status: "accepted",
                updatedAt: { gte: startDate },
            },
            select: {
                total: true,
                updatedAt: true,
            },
            orderBy: { updatedAt: "asc" },
        });

        // Group by day
        const timeline = quotes.reduce((acc, quote) => {
            const day = quote.updatedAt.toISOString().split("T")[0];
            if (!acc[day]) {
                acc[day] = 0;
            }
            acc[day] += quote.total;
            return acc;
        }, {} as Record<string, number>);

        res.json(timeline);
    } catch (error) {
        logger.error({ error }, "Failed to fetch revenue timeline");
        res.status(500).json({ error: "Failed to fetch revenue timeline" });
    }
});

// System health
router.get("/system/health", async (_req: Request, res: Response) => {
    try {
        // Check database connection
        await prisma.$queryRaw`SELECT 1`;

        const cacheStats = cache.getStats();

        res.json({
            status: "healthy",
            database: "connected",
            cache: {
                size: cacheStats.size,
                hitRate: cache.getHitRate(),
            },
            timestamp: new Date().toISOString(),
        });
    } catch (error) {
        logger.error({ error }, "Health check failed");
        res.status(500).json({
            status: "unhealthy",
            error: error instanceof Error ? error.message : "Unknown error",
        });
    }
});

// Revenue chart data
router.get("/revenue", (req: Request, res: Response) => {
    const period = (req.query.period as string) || '7d';
    const data = generateRevenueData(period as '24h' | '7d' | '30d' | '90d');
    res.json(data);
});

// Service distribution chart data
router.get("/services", (_req: Request, res: Response) => {
    const serviceDistribution = [
        { name: 'Standard Rengøring', value: 145, color: '#00d4ff' },
        { name: 'Dybderengøring', value: 87, color: '#00ff88' },
        { name: 'Vinduespudsning', value: 62, color: '#ffd93d' },
        { name: 'Flytning', value: 34, color: '#ff0066' },
        { name: 'Erhverv', value: 28, color: '#9333ea' },
    ];
    res.json(serviceDistribution);
});

/**
 * Generate mock revenue data based on period
 */
function generateRevenueData(period: '24h' | '7d' | '30d' | '90d'): Array<{ date: string; revenue: number }> {
    const data: Array<{ date: string; revenue: number }> = [];
    const now = new Date();

    if (period === '24h') {
        for (let i = 23; i >= 0; i--) {
            const hour = new Date(now.getTime() - i * 60 * 60 * 1000);
            data.push({
                date: `${hour.getHours()}:00`,
                revenue: Math.floor(Math.random() * 5000) + 2000,
            });
        }
    } else if (period === '7d') {
        const days = ['Søn', 'Man', 'Tir', 'Ons', 'Tor', 'Fre', 'Lør'];
        for (let i = 6; i >= 0; i--) {
            const day = new Date(now.getTime() - i * 24 * 60 * 60 * 1000);
            data.push({
                date: days[day.getDay()],
                revenue: Math.floor(Math.random() * 25000) + 15000,
            });
        }
    } else if (period === '30d') {
        for (let i = 4; i >= 0; i--) {
            data.push({
                date: `Uge ${5 - i}`,
                revenue: Math.floor(Math.random() * 80000) + 50000,
            });
        }
    } else if (period === '90d') {
        const months = ['Juli', 'August', 'September'];
        for (let i = 0; i < 3; i++) {
            data.push({
                date: months[i],
                revenue: Math.floor(Math.random() * 200000) + 150000,
            });
        }
    }

    return data;
}

export default router;
