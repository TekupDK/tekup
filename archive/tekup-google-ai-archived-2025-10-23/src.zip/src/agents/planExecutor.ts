import type { PlannedTask, ExecutionResult } from "../types";
import { logger } from "../logger";
import {
    handleEmailCompose,
    handleComplaintEmail,
    handleCalendarBook,
    handleCalendarReschedule,
    handleMemoryUpdate,
    handleAutomationUpdate,
    handleAnalytics,
    type TaskHandler,
    type ExecutionAction,
} from "./handlers";

interface TaskOutcome {
    action: ExecutionAction;
    stop: boolean;
}

const defaultHandlers: Record<string, TaskHandler> = {
    "email.compose": handleEmailCompose,
    "email.resolveComplaint": handleComplaintEmail,
    "calendar.book": handleCalendarBook,
    "calendar.reschedule": handleCalendarReschedule,
    "memory.update": handleMemoryUpdate,
    "automation.updateRule": handleAutomationUpdate,
    "analytics.generate": handleAnalytics,
};

export class PlanExecutor {
    private readonly handlers: Record<string, TaskHandler>;

    constructor(overrides: Record<string, TaskHandler> = {}) {
        this.handlers = { ...defaultHandlers, ...overrides };
    }

    async execute(plan: PlannedTask[]): Promise<ExecutionResult> {
        const actions: ExecutionAction[] = [];

        for (const task of plan) {
            const outcome = await this.runTask(task);
            actions.push(outcome.action);
            if (outcome.stop) {
                break;
            }
        }

        return {
            summary: buildSummary(actions),
            actions,
        };
    }

    private async runTask(task: PlannedTask): Promise<TaskOutcome> {
        const handler = this.handlers[task.type];
        if (!handler) {
            return { action: handleUnknown(task), stop: false };
        }

        try {
            const action = await handler(task);
            return { action, stop: false };
        } catch (error) {
            logger.error({ task, err: error }, "Task execution failed");
            return {
                action: {
                    taskId: task.id,
                    provider: task.provider,
                    status: "failed",
                    detail: `Fejl: ${String((error as Error).message ?? error)}`,
                },
                stop: task.blocking,
            } satisfies TaskOutcome;
        }
    }
}

function handleUnknown(task: PlannedTask): ExecutionAction {
    logger.debug({ task }, "No executor for task; skipping");
    return {
        taskId: task.id,
        provider: task.provider,
        status: "skipped",
        detail: `Ingen eksekvering implementeret for ${task.type}`,
    } satisfies ExecutionAction;
}

function buildSummary(actions: ExecutionAction[]): string {
    // Return single action detail directly for analytics/queries
    if (shouldReturnSingleActionDetail(actions)) {
        return actions[0].detail;
    }

    // Combine multiple detailed actions
    if (hasMultipleDetailedActions(actions)) {
        return combineActionDetails(actions);
    }

    // Fallback to generic summary
    return buildGenericSummary(actions);
}

function shouldReturnSingleActionDetail(actions: ExecutionAction[]): boolean {
    return actions.length === 1 &&
        actions[0].status === "success" &&
        Boolean(actions[0].detail);
}

function hasMultipleDetailedActions(actions: ExecutionAction[]): boolean {
    return actions.length > 0 &&
        actions.some(a => a.detail && a.detail.length > 50);
}

function combineActionDetails(actions: ExecutionAction[]): string {
    return actions
        .filter(a => a.status === "success" && a.detail)
        .map(a => a.detail)
        .join("\n\n");
}

function buildGenericSummary(actions: ExecutionAction[]): string {
    const success = actions.filter((action) => action.status === "success").length;
    const queued = actions.filter((action) => action.status === "queued").length;
    const failed = actions.filter((action) => action.status === "failed").length;

    return `Plan eksekveret: ${success} succes, ${queued} i kø, ${failed} fejlede.`;
}

