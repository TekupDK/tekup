import type { Request, Response, NextFunction } from "express";
import { z, ZodError } from "zod";
import { nanoid } from "nanoid";
import { IntentClassifier } from "../agents/intentClassifier";
import { TaskPlanner } from "../agents/taskPlanner";
import { PlanExecutor } from "../agents/planExecutor";
import { appConfig } from "../config";
import { logger } from "../logger";
import { appendHistory, getHistory } from "../services/memoryStore";
import { AppError } from "../errors";
import type { AssistantResponse, ChatMessage, ChatSessionContext, LeadInformation } from "../types";
import { OpenAiProvider } from "../llm/openAiProvider";

const ChatRequestSchema = z.object({
    message: z.string().min(1, "message is required"),
    sessionId: z.string().optional(),
    userId: z.string().optional(),
    channel: z.enum(["mobile", "tablet", "desktop", "web"]).optional(),
    locale: z.string().optional(),
    lead: z
        .object({
            source: z.string().optional(),
            name: z.string().optional(),
            email: z.string().email().optional(),
            phone: z.string().optional(),
            address: z.string().optional(),
            squareMeters: z.number().optional(),
            rooms: z.number().optional(),
            taskType: z.string().optional(),
            preferredDates: z.array(z.string()).optional(),
        })
        .optional(),
    history: z
        .array(
            z.object({
                role: z.enum(["user", "assistant", "system"]),
                content: z.string(),
                timestamp: z.string().optional(),
            })
        )
        .optional(),
});

const planner = new TaskPlanner();
const executor = new PlanExecutor();
const classifier = (() => {
    try {
        if (!appConfig.llm.OPENAI_API_KEY) {
            return new IntentClassifier();
        }

        const provider = new OpenAiProvider(appConfig.llm.OPENAI_API_KEY);
        return new IntentClassifier({ llm: provider, threshold: 0.7 });
    } catch (error) {
        logger.warn({ err: error }, "Falling back to heuristic classifier");
        return new IntentClassifier();
    }
})();

export async function handleChat(
    req: Request,
    res: Response,
    _next: NextFunction
): Promise<void> {
    try {
        const parsed = ChatRequestSchema.parse(req.body);
        const sessionId = parsed.sessionId ?? nanoid(12);
        const history = parsed.history ?? getHistory(sessionId);

        const context: ChatSessionContext = {
            userId: parsed.userId,
            channel: parsed.channel,
            locale: parsed.locale,
            history,
        };

        // Add enriched context from Gmail/Calendar if available
        const enrichedContext = (req as any).enrichedContext;
        if (enrichedContext?.contextSummary) {
            logger.debug({ sessionId }, "Using enriched context from Gmail/Calendar");
            // Add context summary as a system message at the start
            history.unshift({
                role: "system",
                content: `Context: ${enrichedContext.contextSummary}`,
                timestamp: new Date().toISOString(),
            });
        }

        const userMessage: ChatMessage = {
            role: "user",
            content: parsed.message,
            timestamp: new Date().toISOString(),
        };
        appendHistory(sessionId, userMessage);

        const intent = await classifier.classify(parsed.message, history);
        const plan = planner.plan({
            intent,
            message: parsed.message,
            context,
            lead: parsed.lead as LeadInformation | undefined,
        });
        const execution = await executor.execute(plan);

        const assistantMessage: ChatMessage = {
            role: "assistant",
            content: execution.summary,
            timestamp: new Date().toISOString(),
        };
        appendHistory(sessionId, assistantMessage);

        const response: AssistantResponse = {
            intent,
            plan,
            execution,
        };

        res.json({ sessionId, response });
    } catch (err: unknown) {
        if (err instanceof ZodError) {
            throw new AppError(
                "VALIDATION_ERROR",
                "Invalid request payload",
                400,
                err.issues
            );
        }

        if (err instanceof AppError) {
            throw err;
        }

        logger.error({ err }, "Chat handling failed");
        throw new AppError(
            "CHAT_PROCESSING_ERROR",
            "Failed to process chat message",
            500,
            err
        );
    }
}
